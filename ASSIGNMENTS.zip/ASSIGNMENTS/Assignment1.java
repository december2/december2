import java.util.Scanner;

public class Assignment7
{
    public static void main(String args[]) 
    { 
        Scanner in = new Scanner(System.in);
        System.out.print("Enter number of students: ");
        int n = in.nextInt();
        
        int id[] = new int[n];
        String name[] = new String[n];
        int age[] = new int[n];
        double avg[] = new double[n];
   
        for (int i = 0; i < n; i++) 
        {
            System.out.println("Enter student " + (i+1) + " details:");
            System.out.print("Id: ");
            id[i] = in.nextInt();
            in.nextLine();
            System.out.print("Name: ");
            name[i] = in.nextLine();
            in.nextLine();
            System.out.print("Age: ");
            age[i] = in.nextInt();
            in.nextLine();
        }
        
        System.out.println("Id\tName\tAge\t");
        for (int i = 0; i < n; i++)
        {
             System.out.println(id[i] + "\t" + name[i] + "\t"  + age[i] + "\t");
        }
    }
} 