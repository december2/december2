import java.util.Scanner;
 public class Assignment7a 
{
 public static void main(String args[]) 
 { 
  final int TOTAL_STUDENTS = 10; 
  Scanner in = new Scanner(System.in); 
  int id[] = new int[TOTAL_STUDENTS]; 
  String name[] = new String[TOTAL_STUDENTS]; 
  int age[] = new int[TOTAL_STUDENTS];
  double p[] = new double[TOTAL_STUDENTS]; 
  char g[] = new char[TOTAL_STUDENTS]; 
 {
   System.out.println("Display 10 student details:");
   System.out.println("Id1:17431 "); 
   System.out.println("Id2:17432 ");
   System.out.println("Id3:17433 ");
   System.out.println("Id4:17434 ");
   System.out.println("Id5:17435 ");
   System.out.println("Id6:17436 ");
   System.out.println("Id7:17437 ");
   System.out.println("Id8:17438 ");
   System.out.println("Id9:17439 ");
   System.out.println("Id10:174310 ");
   System.out.println("\t");
   System.out.println("Name1:Bhargavi ");
   System.out.println("Name2:Bhavya ");
   System.out.println("Name3:Bharu ");
   System.out.println("Name4:Bharathi ");
   System.out.println("Name5:Bhavani ");
   System.out.println("Name6:Bhavana ");
   System.out.println("Name7:Bhanu ");
   System.out.println("Name8:Bhagya ");
   System.out.println("Name9:Bhagi ");
   System.out.println("Name10:Bhindhu ");
   System.out.println("\t"); 
   System.out.println("Age1:21 ");
   System.out.println("Age2:21 ");
   System.out.println("Age3:21 ");
   System.out.println("Age4:21 ");
   System.out.println("Age5:21 ");
   System.out.println("Age6:21 ");
   System.out.println("Age7:21 ");
   System.out.println("Age8:21 ");
   System.out.println("Age9:21 ");
   System.out.println("Age10:21 ");
   System.out.println("\t");
   { 
    System.out.println("\t" );
   }
  }
 }
}