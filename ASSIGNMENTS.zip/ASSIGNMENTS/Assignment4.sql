 DECLARE @tbl TABLE(CityName VARCHAR(100)); 
 INSERT INTO @tbl VALUES ('xy'),('Long name'),('very long name'),('middle'),('extremely long name');

 WITH MyCTE AS
 (
   SELECT MAX(LEN(CityName)) AS Longest ,
          MIN(LEN(CityName)) AS Shortest 
          FROM @tbl 
 ) 

  SELECT * 
  FROM MyCTE 
  CROSS APPLY(SELECT TOP 1 CityName FROM @tbl WHERE LEN(CityName)=Longest) AS LongestCity(LongName) 
  CROSS APPLY(SELECT TOP 1 CityName FROM @tbl WHERE LEN(CityName)=Shortest) AS ShortestCity(ShortName)