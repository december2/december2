Import java.util.Calendar;
public Class Ramzan
{
  public static void main(String[] args)
  {
    Calendar obj = Calendar.getInstance();
    obj.set(2021, 04, 13);
    int nod = (int) (29.5*12);
    for(int i=0; i<10; i++)
    {
     obj.add(Calendar.DATE,nod);
     System.out.println(obj.get(Calendar.DATE)+"-"+obj.get(Calendar.MONTH)+"-"+obj.get(Calendar.YEAR));
    }
  }
} 