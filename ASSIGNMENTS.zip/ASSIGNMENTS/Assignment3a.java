Public class Assignment3a
{
 Public static void main (String[] args)
 {
   Calander obj = Calander.getInstance();
   obj.set(2021, 04, 13)
   int nod = (int)(29.5*12);
   int nod1 = (int)(29.5*13);
   int flag = 2;
   for(int i=0; i<10; i++)
   {
     if(flag==3)
     {
       obj.add(Calendar.DATE,nod1);
       flag=1;
     }
      else
      {
        obj.add(Calendar.DATE,nod);
        flag++;
      }
       System.out.println(obj.get(Calendar.DATE)+"-"+obj.get(Calendar.MONTH)+"-"+obj.get(Calendar.YEAR));
   }
 }
}
 