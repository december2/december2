CREATE FUNCTION [dbo].
[fn_WordCount] ( @Bhagi VARCHAR(4000) )  
RETURNS INT 
AS 
BEGIN
DECLARE @Index          INT  
DECLARE @Char           CHAR(1)  
DECLARE @PrevChar       CHAR(1)  
DECLARE @WordCount      INT  
SET @Index = 1  
SET @WordCount = 0   

WHILE @Index <= LEN(@Bhagi)  
BEGIN      
    SET @Char     = SUBSTRING(@Bhagi, @Index, 1)      
    SET @PrevChar = CASE WHEN @Index = 1 THEN ' '                           
                         ELSE SUBSTRING(@Bhagi, @Index - 1, 1)                      
                    END        
    IF @PrevChar = ' ' AND @Char != ' '          
       SET @WordCount = @WordCount + 1        

    SET @Index = @Index + 1  
END  
RETURN @WordCount  
END  
